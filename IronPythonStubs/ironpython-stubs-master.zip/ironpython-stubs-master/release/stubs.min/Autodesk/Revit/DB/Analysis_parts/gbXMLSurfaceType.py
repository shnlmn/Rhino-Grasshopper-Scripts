class gbXMLSurfaceType(Enum,IComparable,IFormattable,IConvertible):
 """
 This enumeration corresponds to the surfaceType attribute in gbXML

    and identifies the type of surface defined.

 

 enum gbXMLSurfaceType,values: Ceiling (7),ExteriorWall (1),InteriorFloor (3),InteriorWall (0),NoOfSurfaceTypes (12),RaisedFloor (10),Roof (2),Shade (4),SlabOnGrade (11),SurfaceAir (8),UndergroundCeiling (9),UndergroundSlab (6),UndergroundWall (5)
 """
 def __eq__(self,*args):
  """ x.__eq__(y) <==> x==yx.__eq__(y) <==> x==yx.__eq__(y) <==> x==y """
  pass
 def __format__(self,*args):
  """ __format__(formattable: IFormattable,format: str) -> str """
  pass
 def __ge__(self,*args):
  pass
 def __gt__(self,*args):
  pass
 def __init__(self,*args):
  """ x.__init__(...) initializes x; see x.__class__.__doc__ for signaturex.__init__(...) initializes x; see x.__class__.__doc__ for signaturex.__init__(...) initializes x; see x.__class__.__doc__ for signature """
  pass
 def __le__(self,*args):
  pass
 def __lt__(self,*args):
  pass
 def __ne__(self,*args):
  pass
 def __reduce_ex__(self,*args):
  pass
 def __str__(self,*args):
  pass
 Ceiling=None
 ExteriorWall=None
 InteriorFloor=None
 InteriorWall=None
 NoOfSurfaceTypes=None
 RaisedFloor=None
 Roof=None
 Shade=None
 SlabOnGrade=None
 SurfaceAir=None
 UndergroundCeiling=None
 UndergroundSlab=None
 UndergroundWall=None
 value__=None

