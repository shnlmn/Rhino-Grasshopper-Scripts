class CADExportOptions(object):
 """ Generic CAD Export options. """
